import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class outbreaker extends PApplet {

Jogador jogador = new Jogador();
Bola bola = new Bola(jogador);
Barras[][] barras = new Barras[10][7];
int score, vida;
boolean jogoAcabou, jogoVenceu = false;
boolean naoComecou = true;
public void setup() {
  vida = 2;
  
  for (int contador = 0; contador<barras.length; contador++) {
    for (int contadorJ = 0; contadorJ<barras[7].length; contadorJ++) {
      barras[contador][contadorJ] = new Barras(contador*60, (20*contadorJ)+80);
    }
  }
}

public void draw() {
  background(0);
  if (jogoAcabou == false) {
    textSize(40);
    text(score, 270, 50);
    bola.desenhaBola(jogador);
    bola.colisao(jogador);
    jogador.desenhaMove();
    for (int contador = 0; contador<barras.length; contador++) {
      for (int contadorJ = 1; contadorJ<barras[7].length; contadorJ++) {
        fill(40*contadorJ, 80*contadorJ, 30*contadorJ);
        barras[contador][contadorJ].desenhaBarra();
        barras[contador][contadorJ].colisao(bola);
      }
    }
  }
  if (jogoAcabou == true) {
    if (jogoVenceu ==false) {
      text("Game Over", 210, 250);
    } else {
      text("Você venceu", 210, 250);
    }
    text("Score:" + score, 230, 50);
    text("Pressione na tela", 150, 380);
    text("para recomeçar", 150, 440);
    if (mousePressed == true) {
      jogoAcabou = false;
      naoComecou = true;
      jogoVenceu = false; 
      vida=2;
      score=0;
    }
  }
  if (score==60) {
    jogoVenceu=true;
  }
}
class Barras {
  float posicaoBarraX, posicaoBarraY, larguraBarra, alturaBarra, testarColisaoX, testarColisaoY, distancia;
  boolean estaVivo;
  Barras(int posicaoTempX, int posicaoTempY) {
    this.posicaoBarraX = posicaoTempX;
    this.posicaoBarraY = posicaoTempY;
    this.larguraBarra = 60;
    this.alturaBarra = 20;
    estaVivo = true;
  }

  public void desenhaBarra() {
    noStroke();
    if (estaVivo == true) {
      rect(this.posicaoBarraX, this.posicaoBarraY, this.larguraBarra, this.alturaBarra);
    }
  }
  public void colisao(Bola outro) {
    if (estaVivo == true) {
      testarColisaoX = outro.posicaoBolaX;
      testarColisaoY = outro.posicaoBolaY;

      if (outro.posicaoBolaX < this.posicaoBarraX) {
        testarColisaoX = this.posicaoBarraX;
      } else if (outro.posicaoBolaX > this.posicaoBarraX + this.larguraBarra) {
        testarColisaoX = this.posicaoBarraX + this.larguraBarra;
      }

      if (outro.posicaoBolaY < this.posicaoBarraY) {
        testarColisaoY = this.posicaoBarraY;
      } else if (outro.posicaoBolaY > this.posicaoBarraY + this.alturaBarra) {
        testarColisaoY =  this.posicaoBarraY + this.alturaBarra;
      }
      this.distancia = sqrt(sq(outro.posicaoBolaX - testarColisaoX) + sq(outro.posicaoBolaY - testarColisaoY));

      if ( this.distancia <= outro.raio) {
        estaVivo = false; 
        outro.aceleracaoY = 5;
        score+=1;
        if (testarColisaoY == this.posicaoBarraY) {
          outro.aceleracaoY = -5;
        }
      }
    }
    if (jogoAcabou ==true)
      estaVivo=true;
  }
}

class Bola {
  float posicaoBolaX, posicaoBolaY, aceleracaoX, aceleracaoY, testarColisaoX, testarColisaoY, distancia, raio;
  Bola(Jogador outro) {
    this.posicaoBolaX = outro.posicaoJogadorX;
    this.posicaoBolaY = outro.posicaoJogadorY;
    this.aceleracaoX = 5;
    this.aceleracaoY = 3;
    this.raio = 10;
  }
  public void desenhaBola(Jogador outro) {
    noStroke();
    if (naoComecou==true) {
      this.posicaoBolaX = outro.posicaoJogadorX+50;
      this.posicaoBolaY = outro.posicaoJogadorY-10;
    }
    text(vida, 400, 50);
    fill(255);
    circle(this.posicaoBolaX, this.posicaoBolaY, this.raio*2);
    if (naoComecou == false) {
      moverBola();
    }
    if (keyPressed ==true) {
      if (keyCode == UP) {
        naoComecou = false;
      }
    }
  }
  public void moverBola() {
    this.posicaoBolaX+=this.aceleracaoX;
    if (this.posicaoBolaX >= width) {
      this.aceleracaoX = -5;
    }
    if (this.posicaoBolaX <= 0) {
      this.aceleracaoX = 5;
    }
    this.posicaoBolaY+=this.aceleracaoY;
    this.aceleracaoY+= 0.01f;
    if (this.posicaoBolaY >= height) {
      vida-=1;
      naoComecou=true;
      if (vida ==0) {
        jogoAcabou =true;
      }
    }
    if (this.posicaoBolaY <= 0) {
      this.aceleracaoY = 5;
    }
    if (jogoVenceu == true) {
      jogoAcabou = true;
    }
  }
  public void colisao(Jogador outro) {
    testarColisaoX = this.posicaoBolaX;
    testarColisaoY = this.posicaoBolaY;

    if (this.posicaoBolaX < outro.posicaoJogadorX) {
      testarColisaoX = outro.posicaoJogadorX;
    } else if (this.posicaoBolaX > outro.posicaoJogadorX + outro.larguraJogador) {
      testarColisaoX = outro.posicaoJogadorX + outro.larguraJogador;
    }

    if (this.posicaoBolaY < outro.posicaoJogadorY) {
      testarColisaoY = outro.posicaoJogadorY;
    } else if (this.posicaoBolaY > outro.posicaoJogadorY + outro.alturaJogador) {
      testarColisaoY =  outro.posicaoJogadorY + outro.alturaJogador;
    }
    this.distancia = sqrt(sq(this.posicaoBolaX - testarColisaoX) + sq(this.posicaoBolaY - testarColisaoY));

    if ( this.distancia <= this.raio) {
      this.aceleracaoY = 5;
      if (testarColisaoY == outro.posicaoJogadorY) {
        this.aceleracaoY = -5;
      }
    }
  }
}

class Jogador {
  float posicaoJogadorX, posicaoJogadorY, larguraJogador, alturaJogador; 
  Jogador() {
    this.posicaoJogadorY = 550;
    this.larguraJogador = 100;
    this.alturaJogador = 20;
  }
  public void desenhaMove() {
    stroke(1);
    rect(this.posicaoJogadorX, this.posicaoJogadorY, this.larguraJogador, this.alturaJogador);
    if (keyPressed) {
      if ( (keyCode == LEFT) && (this.posicaoJogadorX >=0))
        this.posicaoJogadorX-= 7;
      if ( (keyCode == RIGHT) && (this.posicaoJogadorX <=width-larguraJogador))
        this.posicaoJogadorX+=7;
    }
  }
}
  public void settings() {  size(600, 600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "outbreaker" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
